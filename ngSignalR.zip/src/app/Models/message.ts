export class Message {
    clientuniqueid: string;
    type: string;
    message: string;
    date: Date;
  }
